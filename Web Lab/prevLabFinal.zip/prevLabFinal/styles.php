<html>
    <style>
        body {
    font-family: Arial, sans-serif;
    text-align: center;
}

nav ul {
    list-style: none;
    padding: 0;
}

nav ul li {
    display: inline;
    margin: 10px;
}

#menu {
    height:20px;
    color:white;
    background-color:#23486A;
}
#menu a{
    color:white;
}

.submenu {
    display: none;
    position: absolute;
    background: white;
}

.dropdown:hover .submenu {
    display: block;
}

    </style>
</html>