<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li class="dropdown">
            <a href="#">About Me</a>
            <ul class="submenu">
                <li><a href="personal_info.php">Personal Info</a></li>
                <li><a href="education_info.php">Education Info</a></li>
                <li><a href="work_info.php">Work Info</a></li>
            </ul>
        </li>
        <li><a href="contact.php">Contact Me</a></li>
        <li><a href="admin.php">Admin</a></li>
    </ul>
</nav>

