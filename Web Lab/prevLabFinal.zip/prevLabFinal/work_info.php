<?php include 'db_config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Work Info</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'nav.php'; ?>
    
    <div class="mainContent">
        <div class="container2">
            <h1>Work Experience</h1>
            <div class="table">

                <table border="1">
                    <tr><th>Company</th><th>Role</th><th>Years</th></tr>
                    <tr><td>ABC Corp</td><td>Software Developer</td><td>2023 - Present</td></tr>
                    <tr><td>Tech Solutions</td><td>Intern</td><td>2022 - 2023</td></tr>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
