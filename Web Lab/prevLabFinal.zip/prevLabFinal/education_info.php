<?php include 'db_config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Education Info</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'nav.php'; ?>
    <div class="mainContent">
        <div class="container2">

            <h1>Education Information</h1>
            <div class="table">

                <table border="1">
                    <tr><th>Degree</th><th>University</th><th>Year</th></tr>
                    <tr><td>Bachelor's in Computer Science</td><td>XYZ University</td><td>2023</td></tr>
                    <tr><td>High School</td><td>ABC High School</td><td>2019</td></tr>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
