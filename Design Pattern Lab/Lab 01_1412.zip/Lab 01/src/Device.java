public interface Device {
    void powerOn();
    void powerOff();
}
