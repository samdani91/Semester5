public interface LibraryAccess {
    void accessItem(String itemID, User user);
}
