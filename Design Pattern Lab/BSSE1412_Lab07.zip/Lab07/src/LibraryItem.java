public interface LibraryItem {
    String getDetails();
    void borrowItem(String userID);
}
