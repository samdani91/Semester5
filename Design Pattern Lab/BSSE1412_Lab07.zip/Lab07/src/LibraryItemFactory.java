public  abstract class LibraryItemFactory {
    public abstract LibraryItem createLibraryItem(String title, String detail);
}
